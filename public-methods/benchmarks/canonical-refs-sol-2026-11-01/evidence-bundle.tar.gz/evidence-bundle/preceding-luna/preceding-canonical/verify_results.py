#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
def read(name):return json.loads((root/name).read_text())
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode()).hexdigest()
for line in (root/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);p=(root/name).resolve();assert p.is_relative_to(root.resolve());assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
s=read('summary.json');answers=read('answers-and-checks.json')['runs'];receipts=read('provider-receipts.json')['runs'];exposure=read('actual-reference-exposures.json')['runs'];checks=read('reference-verification.json')['runs']
assert len(s['runs'])==len(answers)==len(receipts)==len(exposure)==len(checks)==18
byrun={r['id']:r for r in s['runs']};byanswer={r['id']:r for r in answers}
approved=read('approved-source-manifest.json')['sources'];approved={(r['source_url'],r['sha256'],r['version']):r for r in approved}
for record in receipts:
 run=byrun[record['run']];events=record['receipts'];assert len(events)==run['model_calls'];totals=dict(input_tokens=0,output_tokens=0,total_tokens=0,cached_input_tokens=0)
 for event in events:
  u=event.get('usage');assert isinstance(u,dict),record['run'];assert all(type(u.get(k)) is int and u[k]>=0 for k in ('input_tokens','output_tokens','total_tokens'));assert u['input_tokens']+u['output_tokens']==u['total_tokens']
  cached=u.get('input_tokens_details',{}).get('cached_tokens',0);assert type(cached) is int and 0<=cached<=u['input_tokens']
  for k in ('input_tokens','output_tokens','total_tokens'):totals[k]+=u[k]
  totals['cached_input_tokens']+=cached
 assert all(totals[k]==run[k] for k in totals),record['run']
for record in exposure:
 a=byanswer[record['run']];available={}
 assert len(record['packets'])==len(record['transport_receipts'])
 for packet,receipt in zip(record['packets'],record['transport_receipts']):
  encoded=json.dumps(packet,ensure_ascii=False,separators=(',',':')).encode();assert hashlib.sha256(encoded).hexdigest()==receipt['compact_body_sha256'];assert len(encoded)==receipt['bytes']
 for packet in record['packets']:
  assert packet['schema']=='method-evidence-refs-v3' and packet['policy_version']=='canonical-clause-frame-v3'
  for item in packet['items']:
   source=packet['sources'][item['source_id']];key=(source['source_url'],source['sha256'],source['version']);assert key in approved
   assert all(source[k]==approved[key][k] for k in source)
   assert item['source_id']=='src_'+digest([source['source_url'],source['sha256']])[:32]
   assert len(item['quote'])==item['end']-item['start'] and 0<=item['start']<item['end']
   assert item['evidence_id']=='ev_'+digest([source['source_url'],source['sha256'],item['start'],item['end'],item['quote']])[:32]
   available[item['evidence_id']]=(source,item)
 raw=a['raw_final_text'];assert hashlib.sha256(raw.encode()).hexdigest()==a['rendering_receipt']['raw_sha256']
 if a['render_success']:
  rawanswer=json.loads(raw);rendered=a['rendered_answer'];assert all(rawanswer[k]==rendered[k] for k in ('decisions','recommendation','uncertainty'))
  selected={ident for ids in rawanswer['evidence'].values() for ident in ids};assert selected=={c['evidence_id'] for c in rendered['evidence']}
  for c in rendered['evidence']:
   source,item=available[c['evidence_id']];assert c['url']==source['source_url'] and c['sha256']==source['sha256'] and c['quote']==item['quote'] and c['start']==item['start'] and c['end']==item['end']
   assert set(c['supports'])=={q for q,ids in rawanswer['evidence'].items() if c['evidence_id'] in ids}
assert sum(r['total_tokens'] for r in s['runs'])==s['experiment_candidate_tokens']
for arm,t in s['totals'].items():
 runs=[r for r in s['runs'] if r['arm']==arm];assert len(runs)==9;assert sum(r['full_success'] for r in runs)==t['full_successes'];assert sum(r['total_tokens'] for r in runs)==t['total_tokens'];assert sum(r['decisions_correct'] for r in runs)==t['decisions_correct']
c=s['comparisons']['source_vs_direct'];d=s['totals']['direct'];t=s['totals']['source'];quality=t['usage_complete'] and d['usage_complete'] and t['time_complete'] and d['time_complete'] and t['full_successes']>=8 and t['full_successes']>=d['full_successes'];assert c['quality_gate_passed']==quality;assert c['primary_token_gate_passed']==bool(quality and c['tokens_per_success_reduction']>=.30)
assert read('predecessors.json')['prior_candidate_runs']==45
print('Verified hashes, all 18 provider usage receipts, raw/rendered correspondence, both-arm authorized reference IDs and summary/gate accounting. Prior 45 retained by immutable link (63 total records).')
