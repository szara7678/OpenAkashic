#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
for line in (root/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);p=(root/name).resolve();assert p.is_relative_to(root.resolve());assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
for phase in ('preceding-canonical','fresh'):subprocess.run([sys.executable,str(root/phase/'verify_results.py')],check=True)
h=json.loads((root/'history.json').read_text());assert h['prior_candidate_runs']==63 and h['fresh_candidate_runs']==18 and h['all_candidate_runs']==81
assert h['prior_candidate_tokens']==2286653
assert h['all_candidate_tokens']==h['prior_candidate_tokens']+h['fresh_candidate_tokens']
print('Verified all bundle hashes and 36 new reference-cohort provider receipts with each frozen policy; prior 45 immutable records linked, 81 candidate records accounted for.')
