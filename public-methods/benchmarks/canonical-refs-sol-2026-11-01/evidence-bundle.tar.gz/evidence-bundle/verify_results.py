#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
for line in (root/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);p=(root/name).resolve();assert p.is_relative_to(root.resolve());assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
for phase in ('preceding-luna','sol'):subprocess.run([sys.executable,str(root/phase/'verify_results.py')],check=True)
h=json.loads((root/'history.json').read_text());assert h['prior_candidate_runs']==81 and h['current_candidate_runs']==18 and h['all_candidate_runs']==99
assert h['prior_candidate_tokens']==3137030;assert h['all_candidate_tokens']==h['prior_candidate_tokens']+h['current_candidate_tokens']
print('Verified 99 candidate records: latest 18 plus 36 archived reference runs with exact receipts, and 45 immutable earlier records linked. No success rates pooled.')
